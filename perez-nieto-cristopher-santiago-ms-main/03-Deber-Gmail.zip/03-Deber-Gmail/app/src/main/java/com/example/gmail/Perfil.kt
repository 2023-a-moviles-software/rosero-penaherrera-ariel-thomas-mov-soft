package com.example.gmail

import com.example.gmail.ui.home.Correo

class Perfil (
    val image: String,
    val correoElectronico: String
    ){
}