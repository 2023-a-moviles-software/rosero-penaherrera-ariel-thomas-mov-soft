package com.example.gmail

class PerfilProvider {
    companion object{
        val perfilesList = listOf<Perfil>(
            Perfil(
                "https://scontent.fuio1-2.fna.fbcdn.net/v/t39.30808-6/286376713_5240522852705735_4217481331298360425_n.jpg?_nc_cat=106&ccb=1-7&_nc_sid=09cbfe&_nc_eui2=AeErhIZDohiWetog8oGmgSWxSN64uvKEWEZI3ri68oRYRkgRhNjvi0jIEkIkaGDwOEVTG4Yh2Mc9YhXCc6qJzxi4&_nc_ohc=Yr4RAtfyamgAX9mzwNm&tn=bDCkrMLfLopfvZ97&_nc_ht=scontent.fuio1-2.fna&oh=00_AfAzfVsX4EkkMH19WsEtS7AAAcdJdaxrKzOTCsKK9RqKnw&oe=63FC99EA",
                "cristopher240871@gmail.com"
            ),
            Perfil(
                "https://scontent.fuio1-2.fna.fbcdn.net/v/t1.6435-9/79944952_447670239518171_2872748172248088576_n.jpg?_nc_cat=101&ccb=1-7&_nc_sid=174925&_nc_eui2=AeGNaL7LuO2FHGLiKpP0Yqxky7p1yuH0HFLLunXK4fQcUjFoKtkYmxoj5aoVnjtumyoXhmY-nsXuXdA5BshOVUgM&_nc_ohc=neTmgCuwwdkAX8kl3Ij&tn=bDCkrMLfLopfvZ97&_nc_ht=scontent.fuio1-2.fna&oh=00_AfAdX72UgudO1OR7Bx6dO0wD4fZKYplThs5eU0n-EhI14A&oe=641E4569",
                "nesisromero04@gmail.com"
            ),
            Perfil(
                "https://scontent.fuio1-2.fna.fbcdn.net/v/t31.18172-8/13988050_1235919686430317_3613538598451032657_o.jpg?_nc_cat=103&ccb=1-7&_nc_sid=8bfeb9&_nc_eui2=AeH8br0D-zCe39H4X1fFHig_Nc0ncZTsKcQ1zSdxlOwpxD0QV66LyhaUQ0-Qdf6GUOdHSp7q_rIn0fvHTEeYM8k_&_nc_ohc=K95ZPFOLvwEAX9o8opY&_nc_ht=scontent.fuio1-2.fna&oh=00_AfBPYykL_Elrum49VXo76pRUfE3ra5o3_nxV7U04cr7oEA&oe=641E5C39",
                "samper001@gmail.com"
            ),
            Perfil(
                "https://scontent.fuio1-1.fna.fbcdn.net/v/t31.18172-8/12365922_949682761791029_8326578978158535117_o.jpg?_nc_cat=104&ccb=1-7&_nc_sid=174925&_nc_eui2=AeGppuWJJh_r4nWfmQJpBUQpKuf9a-kljf8q5_1r6SWN_9qD6ThpaUJGOWzPG05Cu0qq9hqZFNt3D9nS4XpOb68X&_nc_ohc=NM2FeiPZyTIAX_sTT8i&_nc_ht=scontent.fuio1-1.fna&oh=00_AfDlT8D_y1-DBmpN1i488FVjLnxYXYfifo8lrfYAH7dKVg&oe=641E5C1C",
                "flora200573@gmail.com"
            ),
            Perfil(
                "https://scontent.fuio1-2.fna.fbcdn.net/v/t39.30808-6/306508003_2034780983374048_7253437836625119272_n.jpg?_nc_cat=107&ccb=1-7&_nc_sid=174925&_nc_eui2=AeEibdBS5uhTij7vJU3T6a7PttEE79q0pJe20QTv2rSkl3J8sVzXxZbNH7aQNeVVFEwc8PZvX7ii6VDpViZ5MbnT&_nc_ohc=c85qi1PHUhwAX-FC2fG&_nc_ht=scontent.fuio1-2.fna&oh=00_AfCmv2W5y1tKzNvbPysrBC4e7e6xrPFbtH-26Temq1aMNw&oe=63FAD776",
                "trujisman_503@gmail.com"
            )
        )
    }
}