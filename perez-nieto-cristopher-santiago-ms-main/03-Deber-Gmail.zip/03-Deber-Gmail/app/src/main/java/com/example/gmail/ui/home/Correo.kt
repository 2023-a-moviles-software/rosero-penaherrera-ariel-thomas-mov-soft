package com.example.gmail.ui.home

data class Correo (
    val emisor: String,
    val description: String,
    val content: String,
    val photo: String
    ){
}